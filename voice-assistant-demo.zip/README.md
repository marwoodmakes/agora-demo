# Agora AI Voice Assistant Demo

This is a static frontend demo for the Agora AI voice assistant.

## Features
- Click-to-Talk UI
- Mobile responsive
- Styled for demos

## Deployment
Push this to GitHub and connect to Render static hosting.

